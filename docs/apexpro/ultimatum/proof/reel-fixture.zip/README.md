# TCS Evidence Reel
20 seconds, 1080 × 1920. Source is the same dated company brief, not fresh quotes.

Unzip this folder, then run:

npx hyperframes@0.9.55 check
npx hyperframes@0.9.55 render -o TCS-evidence.mp4

Silent by design for paper research. No voiceover or return claims. Rendering uses local HyperFrames tooling; this ZIP is an editable composition, not an MP4.
